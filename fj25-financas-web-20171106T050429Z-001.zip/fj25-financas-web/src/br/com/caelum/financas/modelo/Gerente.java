package br.com.caelum.financas.modelo;

public class Gerente {

}
