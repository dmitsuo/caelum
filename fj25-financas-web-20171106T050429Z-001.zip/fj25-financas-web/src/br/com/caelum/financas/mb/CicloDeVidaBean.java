package br.com.caelum.financas.mb;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class CicloDeVidaBean {
	
	
	public void executeAgendador() {

	
	}
}
