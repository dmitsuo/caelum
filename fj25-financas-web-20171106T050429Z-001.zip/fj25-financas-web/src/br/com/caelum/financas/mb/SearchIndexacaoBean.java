package br.com.caelum.financas.mb;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class SearchIndexacaoBean {


	public void indexar() throws InterruptedException {

	}
	
}
